import React from "react";
import Styles from "./register.module.css";

const RegImage = () => {
  return <aside className={Styles.imageBlock}></aside>;
};

export default RegImage;
